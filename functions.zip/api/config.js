async function loadCloudflareConfig() {
    try {
        const response = await fetch('/api/config');
        if (!response.ok) throw new Error('Config fetch failed');
        
        const config = await response.json();
        
        window.SUPABASE_URL = config.supabaseUrl;
        window.SUPABASE_KEY = config.supabaseKey;
        window.ADMIN_EMAIL = config.adminEmail;
        window.ADMIN_BACKUP = config.adminBackup;
        
        // window.supabase ရှိမရှိ စစ်ဆေးပြီး မရှိသေးရင် အသစ်ဆောက်ပါ
        if (!window.supabase && window.supabaseClient) {
            window.supabase = window.supabaseClient.createClient(
                window.SUPABASE_URL, 
                window.SUPABASE_KEY
            );
        } else if (typeof supabase !== 'undefined' && !window.supabase) {
            window.supabase = supabase.createClient(
                window.SUPABASE_URL, 
                window.SUPABASE_KEY
            );
        }
        
        console.log('✅ Base Config loaded');
        return true;
        
    } catch (error) {
        console.error('❌ Config load error:', error);
        return false;
    }
}
