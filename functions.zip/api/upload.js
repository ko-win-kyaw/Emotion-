export async function onRequest(context) {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };

    if (context.request.method === 'OPTIONS') {
        return new Response(null, { headers });
    }

    if (context.request.method !== 'POST') {
        return new Response(JSON.stringify({ success: false, error: "POST request သာ ခွင့်ပြုပါသည်" }), { status: 405, headers });
    }

    try {
        const formData = await context.request.formData();
        const file = formData.get('file');

        if (!file) {
            return new Response(JSON.stringify({ success: false, error: "ဖိုင်မတွေ့ပါ" }), { status: 400, headers });
        }

        const isVideo = file.type.startsWith('video/');
        const maxSize = isVideo ? 50 * 1024 * 1024 : 5 * 1024 * 1024; // Video 50MB, Image 5MB

        if (file.size > maxSize) {
            return new Response(JSON.stringify({ 
                success: false, 
                error: `ဖိုင်ဆိုဒ် ကြီးလွန်းပါသည်။ အများဆုံး ${isVideo ? '50MB' : '5MB'} သာ ခွင့်ပြုပါသည်။` 
            }), { status: 400, headers });
        }

        // ဖိုင်နာမည်မှာ မြန်မာစာ သို့မဟုတ် Space ပါရင် Error မတက်အောင် Date.now() သုံးပြီး URL safe ဖြစ်အောင်လုပ်ခြင်း
        const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;

        if (isVideo) {
            // Bunny.net upload လုပ်တဲ့အခါ file direct မဟုတ်ဘဲ ArrayBuffer သို့မဟုတ် Stream သုံးရင် ပိုစိတ်ချရပါတယ်
            const arrayBuffer = await file.arrayBuffer();
            
            const response = await fetch(
                `https://sg.storage.bunnycdn.com/${context.env.BUNNY_STORAGE}/${fileName}`,
                {
                    method: 'PUT',
                    headers: { 'AccessKey': context.env.BUNNY_KEY },
                    body: arrayBuffer
                }
            );
            
            if (!response.ok) throw new Error('Bunny storage upload failed');
            
            return new Response(JSON.stringify({
                success: true,
                url: `https://public-hospitals.b-cdn.net/${fileName}`,
                type: 'video'
            }), { headers });
            
        } else {
            // ImgBB upload
            const imgbbFormData = new FormData();
            imgbbFormData.append('image', file);
            
            const response = await fetch(
                `https://api.imgbb.com/1/upload?key=${context.env.IMGBB_KEY}`,
                { method: 'POST', body: imgbbFormData }
            );
            
            const result = await response.json();
            if (!result.success) throw new Error('ImgBB upload failed');
            
            return new Response(JSON.stringify({
                success: true,
                url: result.data.url,
                type: 'image'
            }), { headers });
        }

    } catch (error) {
        return new Response(JSON.stringify({ 
            success: false, 
            error: error.message 
        }), { status: 500, headers });
    }
}

